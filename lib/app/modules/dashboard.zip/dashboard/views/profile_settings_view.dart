import 'package:flutter/material.dart';

import 'package:get/get.dart';

class ProfileSettingsView extends GetView {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Text(
          'ProfileSettingsView is working',
          style: TextStyle(fontSize: 20),
        ),
      ),
    );
  }
}
